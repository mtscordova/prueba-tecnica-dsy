


Install all the dependencies using composer

    composer install


Install all node dependencies using npm

    npm install


Start the local development server

    php artisan serve

You can now access the server at http://localhost:8000
